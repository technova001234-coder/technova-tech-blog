// ===============================
// TechNova JavaScript
// ===============================

// Dark Mode Toggle
const darkBtn = document.getElementById("darkBtn");

if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark-mode");
}

if (darkBtn) {
    darkBtn.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");

        if (document.body.classList.contains("dark-mode")) {
            localStorage.setItem("theme", "dark");
        } else {
            localStorage.setItem("theme", "light");
        }
    });
}

// Newsletter Validation
const emailInput = document.querySelector('input[type="email"]');
const subscribeBtn = document.querySelector(".newsletter button");

if (subscribeBtn && emailInput) {
    subscribeBtn.addEventListener("click", () => {

        const email = emailInput.value.trim();

        if (email === "") {
            alert("Please enter your email.");
            return;
        }

        if (!email.includes("@")) {
            alert("Please enter a valid email.");
            return;
        }

        alert("Thank you for subscribing!");
        emailInput.value = "";
    });
}

// Search Button Demo
const searchBtn = document.querySelector(".input-group button");
const searchInput = document.querySelector(".input-group input");

if (searchBtn && searchInput) {

    searchBtn.addEventListener("click", () => {

        const text = searchInput.value.trim();

        if (text === "") {
            alert("Please enter something to search.");
            return;
        }

        alert("Searching for: " + text);

    });

}

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(link => {

    link.addEventListener("click", function(e){

        e.preventDefault();

        const target=document.querySelector(this.getAttribute("href"));

        if(target){

            target.scrollIntoView({

                behavior:"smooth"

            });

        }

    });

});